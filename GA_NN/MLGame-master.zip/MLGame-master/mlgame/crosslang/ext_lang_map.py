# The mapping of file extension to the supported language
EXTESION_LANG_MAP = {
    ".cpp": "cpp"
}
