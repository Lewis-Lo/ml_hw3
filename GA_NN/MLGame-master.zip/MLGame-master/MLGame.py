from mlgame.execution import execute

if __name__ == "__main__":
    execute()
